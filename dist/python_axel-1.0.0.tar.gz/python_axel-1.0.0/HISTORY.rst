=======
History
=======

0.0.0 (2022-05-28)
------------------

* First release on PyPI.
